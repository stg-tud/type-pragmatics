package org.spoofax.interpreter.adapter.ecj;

import org.spoofax.terms.StrategoString;

public class ECJString extends StrategoString {

    private static final long serialVersionUID = 1L;

    protected ECJString(String value) {
        super(value);
    }
}
