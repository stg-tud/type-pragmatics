package org.metaborg.runtime.task.evaluation;

public enum TaskResultType {
	HigherOrder, Fail, Success
}