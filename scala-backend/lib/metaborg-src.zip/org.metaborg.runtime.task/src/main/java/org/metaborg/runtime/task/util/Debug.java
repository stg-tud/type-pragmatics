package org.metaborg.runtime.task.util;

public final class Debug {
	public static final boolean DEBUGGING = Debug.class.desiredAssertionStatus();
}
