package org.metaborg.runtime.task.engine;

public class TaskRemovalStatus {
	public boolean removed = false;
	public boolean partitionOverride = false;
	public boolean dependencyOverride = false;
	public boolean readOverride = false;
}
