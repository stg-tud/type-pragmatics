package org.metaborg.meta.lang.analysis.strategies;

import org.strategoxt.lang.Context;

public class Main {
  
  public static void init(Context context) {
    // Called when the editor is being initialized
  }

}
