package org.metaborg.meta.lang.analysis;

public class AnalysisParseController extends AnalysisParseControllerGenerated 
{ }